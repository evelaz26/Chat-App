var contacts = {
    "Mary" : ["Mary","Graphics/user.png","11/10/2020 14:59","Yes, I can look into that"],
    "GrandMaster" :["GrandMaster","Graphics/group.png","11/10/2020 14:20","Bill: Sounds Good!"],
    "Bill": ["Bill","Graphics/user.png","11/10/2020 14:00","Can you find another player?"]
}

var chat_hist_bill = [
    ["Hi, I'm Bill","him"],
    ["Hi, Bill","me"],
    ["I was in the GrandMaster group just like you","him"],
    ["Can you find another player?","him"],
]
var chat_hist_mary = [
    ["Hi, I'm Mary","him"],
    ["Nice to meet you","him"],
    ["Hi, Mary","me"],
    ["How are you doing today?","me"],
    ["I'm doing great, what about you?","him"],
    ["good","me"],
    ["Do you play chess?","me"],
    ["Yes","him"],
    ["Can you find another player?","me"],
    ["Yes, I can look into that","him"]
]

var chat_hist_grand = [
    ["Sounds Good!","him"]
]

